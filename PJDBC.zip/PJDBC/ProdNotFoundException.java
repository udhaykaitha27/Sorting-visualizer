package pjdbc;

public class ProdNotFoundException  extends Exception{

}
